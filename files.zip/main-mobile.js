// Simple HTML5 canvas space game - MOBILE OPTIMIZED
// Responsive canvas sizing
let WIDTH, HEIGHT;
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');

// Mobile-specific: Setup responsive canvas
function resizeCanvas() {
  const container = canvas.parentElement;
  const controls = document.querySelector('.controls');
  const controlsHeight = controls ? controls.offsetHeight : 0;
  
  // Calculate available space
  const availWidth = window.innerWidth;
  const availHeight = window.innerHeight - controlsHeight;
  
  // Maintain aspect ratio (4:3)
  const targetRatio = 4 / 3;
  let canvasWidth, canvasHeight;
  
  if (availWidth / availHeight > targetRatio) {
    // Height constrained
    canvasHeight = availHeight;
    canvasWidth = canvasHeight * targetRatio;
  } else {
    // Width constrained
    canvasWidth = availWidth;
    canvasHeight = canvasWidth / targetRatio;
  }
  
  canvas.width = canvasWidth;
  canvas.height = canvasHeight;
  
  WIDTH = canvasWidth;
  HEIGHT = canvasHeight;
}

// Initial resize
resizeCanvas();

// Resize on orientation change or window resize
window.addEventListener('resize', resizeCanvas);
window.addEventListener('orientationchange', () => {
  setTimeout(resizeCanvas, 100);
});

let state = 'splash'; // 'splash' | 'game' | 'gameover'
let splashTimer = 0;
const SPLASH_SECONDS = 10;

// Ship (physics)
const ship = { x: WIDTH/2, y: 400, w: 48, h: 28, vx:0, vy:0, angle: -Math.PI/2 };
const SHIP_THRUST = 220; // acceleration px/sec^2
const SHIP_ROT_SPEED = Math.PI; // rad/sec when rotating
const SHIP_DAMPING = 0.98; // velocity damping per frame
const keys = { left:false, right:false, up:false };

// Meteors
const meteors = [];
const METEOR_COUNT = 6;

// Timing for acceleration
let minuteElapsed = 0;
let redLevel = 0; // 0..255
const RED_INCREASE_PER_MIN = 10; // amount of red added per minute
const OVERLAY_ALPHA = 0.12; // base alpha for red overlay

// Score (increments by 1 per millisecond)
let scoreFloat = 0;
let score = 0;
let bestScore = 0;

// Expose score API for external modules (Shop, etc.) to read/modify safely
window.getGameScore = function(){ return score; };
window.modifyGameScore = function(delta){
  scoreFloat = Math.max(0, (scoreFloat||0) + (delta||0));
  score = Math.floor(scoreFloat);
  return score;
};
window.setGameScore = function(val){ scoreFloat = Math.max(0, Number(val)||0); score = Math.floor(scoreFloat); return score; };

// Progressive speed levels based on score (every 10s / 10000 ms)
let lastSpeedLevel = 0; // how many 10s thresholds we've applied

// Badges
const BADGES = [
  { id: '10s', label: '10s', thresh: 10000, color: '#ffd54f', unlocked: false },
  { id: '30s', label: '30s', thresh: 30000, color: '#ff8a65', unlocked: false },
  { id: '1m', label: '1m', thresh: 60000, color: '#ce93d8', unlocked: false },
  { id: '5m', label: '5m', thresh: 300000, color: '#81c784', unlocked: false }
];
const SAVE_KEY = 'vitjusha_game_save_v1';

function loadSave(){
  try{
    const raw = localStorage.getItem(SAVE_KEY);
    if(!raw) return;
    const obj = JSON.parse(raw);
    if(obj.bestScore) bestScore = obj.bestScore;
    if(obj.badges){
      for(const b of BADGES) if(obj.badges[b.id]) b.unlocked = true;
    }
  }catch(e){console.warn('loadSave failed', e)}
}

function saveNow(){
  try{
    const obj = { bestScore: bestScore, badges: {} };
    for(const b of BADGES) if(b.unlocked) obj.badges[b.id] = true;
    localStorage.setItem(SAVE_KEY, JSON.stringify(obj));
  }catch(e){console.warn('save failed', e)}
}

loadSave();

function rand(min,max){ return Math.random()*(max-min)+min }

function makeMeteor(){
  const r = rand(12, 48);
  const points = [];
  const spikes = Math.floor(rand(6, 12));
  for(let i=0;i<spikes;i++){
    const ang = (i/spikes) * Math.PI*2;
    const rr = r * rand(0.65, 1.1);
    points.push({x: Math.cos(ang)*rr, y: Math.sin(ang)*rr});
  }
  return {
    x: rand(0, WIDTH),
    y: rand(-HEIGHT, 0),
    r: r,
    points: points,
    vx: rand(-40, 40),
    vy: rand(40, 200),
    angle: rand(0, Math.PI*2),
    angular: rand(-1.5, 1.5) // rad/sec
  };
}

function initMeteors(){
  meteors.length = 0;
  for(let i=0;i<METEOR_COUNT;i++) meteors.push(makeMeteor());
}

initMeteors();

// Auto-spawn boss if URL contains ?spawnBoss=1 or ?spawnBoss=true
try{
  const params = new URLSearchParams(location.search);
  if(params.get('spawnBoss') === '1' || params.get('spawnBoss') === 'true'){
    // delay until initialization completes
    setTimeout(()=>{
      try{ spawnBoss(); debugLog('Boss spawned via URL param'); }catch(e){ debugLog('spawnBoss error:'+e.message,'error'); }
      try{ bossAudio = new Audio('boss.mp3'); bossAudio.loop = true; bossAudio.play().catch(()=>{}); }catch(e){}
    }, 250);
  }
}catch(e){}

// DevTools-open detection: if the user opens dev console, spawn boss (one-time)
try{
  let devtoolsOpened = false;
  function checkDevtools(){
    const threshold = 160;
    const opened = (window.outerWidth - window.innerWidth > threshold) || (window.outerHeight - window.innerHeight > threshold);
    if(opened && !devtoolsOpened){
      devtoolsOpened = true;
      debugLog('DevTools detected — spawning boss as requested');
      try{ spawnBoss(); }catch(e){ debugLog('spawnBoss error:'+e.message,'error'); }
    }
  }
  setInterval(checkDevtools, 600);
}catch(e){}

// Cheat options
const cheatOptions = {
  showHitboxes: false,
  noclip: false,
  speedMultiplier: 1.0,
  rainbow: false,
  music: false
};

// Secret-code unlock for Dev Console (only via input field)
const SECRET_CODE = 'ultrahacker228';
let cheatUnlocked = false;

// WebAudio simple music (sine loop) setup
let audioCtx = null;
let musicOsc = null;
let musicGain = null;

// HTML5 audio file playback (preferred for PCK.mp3)
let musicAudio = null;
let bossAudio = null;
let bossStarted = false;
// Boss gameplay state
let bossActive = false;
let boss = null;
const bossBullets = [];
let bossTimer = 0; // seconds since boss started

function startMusic(){
  // prefer playing `PCK.mp3` from project root; fall back to WebAudio tone
  stopFileMusic();
  bossStarted = false;
  try{
    musicAudio = new Audio('PCK.mp3');
    musicAudio.crossOrigin = 'anonymous';
    musicAudio.loop = false;
    musicAudio.play().catch(()=>{});
    // when 29s reached, start boss track if available
    musicAudio.addEventListener('timeupdate', ()=>{
      if(!bossStarted && musicAudio.currentTime >= 29){
        bossStarted = true;
        // Do NOT auto-spawn the boss. Play boss audio (if available) and pause base track.
        try{
          bossAudio = new Audio('boss.mp3');
          bossAudio.loop = true;
          bossAudio.play().catch(()=>{});
          try{ musicAudio.pause(); }catch(e){}
          debugLog('Boss music started at 29s — press Spawn Boss to begin the encounter');
        }catch(e){
          debugLog('Boss audio not available. Press Spawn Boss to start boss gameplay');
        }
      }
    });
  }catch(e){
    // fallback to simple tone
    if(audioCtx) return;
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    musicOsc = audioCtx.createOscillator();
    musicGain = audioCtx.createGain();
    musicOsc.type = 'sine';
    musicOsc.frequency.value = 220; // base tone
    musicGain.gain.value = 0.12; // low volume (raised)
    musicOsc.connect(musicGain);
    musicGain.connect(audioCtx.destination);
    musicOsc.start();
  }
}

function stopMusic(){
  // stop file audio if playing
  try{ if(musicAudio){ musicAudio.pause(); musicAudio.currentTime = 0; } }catch(e){}
  try{ if(bossAudio){ bossAudio.pause(); bossAudio.currentTime = 0; } }catch(e){}
  musicAudio = null; bossAudio = null; bossStarted = false;
  // stop WebAudio fallback
  if(!audioCtx) return;
  try{ musicOsc.stop(); }catch(e){}
  musicOsc.disconnect();
  musicGain.disconnect();
  audioCtx.close();
  audioCtx = null; musicOsc = null; musicGain = null;
}

function stopFileMusic(){
  try{ if(musicAudio){ musicAudio.pause(); musicAudio.currentTime = 0; } }catch(e){}
  try{ if(bossAudio){ bossAudio.pause(); bossAudio.currentTime = 0; } }catch(e){}
  musicAudio = null; bossAudio = null; bossStarted = false;
  // stop boss gameplay
  bossActive = false; boss = null; bossBullets.length = 0; bossTimer = 0;
}

function spawnBoss(){
  bossActive = true;
  boss = { x: WIDTH/2, y: 80, r: 64 };
  bossBullets.length = 0;
  bossTimer = 0;
  // remove all meteors when boss starts
  meteors.length = 0;
}

function spawnBossBullets(b){
  // spawn a mixed pattern: aimed cluster plus rotating ring
  const aimedCount = 3;
  for(let i=0;i<aimedCount;i++){
    const ang = Math.atan2(ship.y - b.y, ship.x - b.x) + (i-1)*0.12;
    const speed = rand(160, 240);
    bossBullets.push({ x: b.x + Math.cos(ang)* (b.r+8), y: b.y + Math.sin(ang)*(b.r+8), vx: Math.cos(ang)*speed, vy: Math.sin(ang)*speed, r:6 });
  }
  // ring
  const ringCount = 8;
  const t = performance.now()*0.002;
  for(let i=0;i<ringCount;i++){
    const ang = (i/ringCount)*Math.PI*2 + t;
    const speed = 120;
    bossBullets.push({ x: b.x + Math.cos(ang)*(b.r+6), y: b.y + Math.sin(ang)*(b.r+6), vx: Math.cos(ang)*speed, vy: Math.sin(ang)*speed, r:5 });
  }
  // do NOT spawn extra meteors during the boss (meteors were cleared when boss started)
}

// Secret code unlocking removed by user request. Cheat panel remains inaccessible via keys.

function showCheatPanel(){
  if(document.getElementById('cheatPanel')) return;
  const panel = document.createElement('div');
  panel.id = 'cheatPanel';
  panel.className = 'cheat-panel';
  panel.innerHTML = `
    <h4>Cheat Panel</h4>
    <label><input type="checkbox" id="chHit"> Show hitboxes</label>
    <label><input type="checkbox" id="chNoclip"> Noclip</label>
    <label>Speed: <input id="chSpeed" type="range" min="0.5" max="3" step="0.1" value="1"></label>
    <label><input type="checkbox" id="chRainbow"> Rainbow background</label>
    <label><input type="checkbox" id="chMusic"> Music</label>
    <div class="cheat-note">Type again after reload to reopen.</div>
  `;
  document.body.appendChild(panel);

  // wire controls
  const chHit = document.getElementById('chHit');
  const chNoclip = document.getElementById('chNoclip');
  const chSpeed = document.getElementById('chSpeed');
  const chRainbow = document.getElementById('chRainbow');
  const chMusic = document.getElementById('chMusic');

  chHit.addEventListener('change', ()=> cheatOptions.showHitboxes = chHit.checked);
  chNoclip.addEventListener('change', ()=> cheatOptions.noclip = chNoclip.checked);
  chSpeed.addEventListener('input', ()=> cheatOptions.speedMultiplier = parseFloat(chSpeed.value));
  chRainbow.addEventListener('change', ()=> cheatOptions.rainbow = chRainbow.checked);
  chMusic.addEventListener('change', ()=>{
    cheatOptions.music = chMusic.checked;
    if(cheatOptions.music) startMusic(); else stopMusic();
  });
}
// Input
// Global keydown: secret-code capture + player controls
window.addEventListener('keydown', e=>{
  // ignore global secret-code capture; secret must be entered via the code input

  // player controls (still work)
  if(e.key==='ArrowLeft' || e.key==='a') keys.left = true;
  if(e.key==='ArrowRight' || e.key==='d') keys.right = true;
  if(e.key==='ArrowUp' || e.key==='w') keys.up = true;
  if(e.key===' ' && state==='gameover') restart();
});
window.addEventListener('keyup', e=>{
  if(e.key==='ArrowLeft' || e.key==='a') keys.left = false;
  if(e.key==='ArrowRight' || e.key==='d') keys.right = false;
  if(e.key==='ArrowUp' || e.key==='w') keys.up = false;
});

// MOBILE: Touch controls
function setupTouchControls() {
  const btnLeft = document.getElementById('btnLeft');
  const btnRight = document.getElementById('btnRight');
  const btnThrust = document.getElementById('btnThrust');
  
  if (btnLeft) {
    btnLeft.addEventListener('touchstart', (e) => {
      e.preventDefault();
      keys.left = true;
    });
    btnLeft.addEventListener('touchend', (e) => {
      e.preventDefault();
      keys.left = false;
    });
    btnLeft.addEventListener('touchcancel', (e) => {
      e.preventDefault();
      keys.left = false;
    });
  }
  
  if (btnRight) {
    btnRight.addEventListener('touchstart', (e) => {
      e.preventDefault();
      keys.right = true;
    });
    btnRight.addEventListener('touchend', (e) => {
      e.preventDefault();
      keys.right = false;
    });
    btnRight.addEventListener('touchcancel', (e) => {
      e.preventDefault();
      keys.right = false;
    });
  }
  
  if (btnThrust) {
    btnThrust.addEventListener('touchstart', (e) => {
      e.preventDefault();
      keys.up = true;
    });
    btnThrust.addEventListener('touchend', (e) => {
      e.preventDefault();
      keys.up = false;
    });
    btnThrust.addEventListener('touchcancel', (e) => {
      e.preventDefault();
      keys.up = false;
    });
  }
  
  // Tap to restart on game over
  canvas.addEventListener('touchstart', (e) => {
    if (state === 'gameover') {
      e.preventDefault();
      restart();
    }
  });
}

// Initialize touch controls when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', setupTouchControls);
} else {
  setupTouchControls();
}

function restart(){
  state = 'splash';
  splashTimer = 0;
  minuteElapsed = 0;
  redLevel = 0;
  ship.x = WIDTH/2;
  initMeteors();
}

// Game loop
let last = performance.now();
function loop(now){
  const dt = Math.min(0.05, (now - last) / 1000);
  last = now;
  update(dt);
  draw();
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);

function update(dt){
  if(state === 'splash'){
    splashTimer += dt;
    if(splashTimer >= SPLASH_SECONDS){
      state = 'game';
    }
    return;
  }

  if(state === 'game'){
    // score increases by 1 per millisecond
    scoreFloat += dt * 1000;
    const newScore = Math.floor(scoreFloat);
    if(newScore !== score){
      score = newScore;
      // check progressive speed levels every 10 seconds (10000 ms)
      const speedLevel = Math.floor(score / 10000);
      const deltaLevels = speedLevel - lastSpeedLevel;
      if(deltaLevels > 0){
        for(let i=0;i<deltaLevels;i++){
          for(const m of meteors){ m.vx *= 1.05; m.vy *= 1.05; } // +5% per 10s
          // also increase red tint slightly
          redLevel = Math.min(255, redLevel + 2);
        }
        lastSpeedLevel = speedLevel;
      }

      // unlock badges if thresholds crossed
      for(const b of BADGES){
        if(!b.unlocked && score >= b.thresh){
          b.unlocked = true;
        }
      }
    }
    // Ship physics: rotation and thrust
    if(keys.left) ship.angle -= SHIP_ROT_SPEED * dt;
    if(keys.right) ship.angle += SHIP_ROT_SPEED * dt;
    if(keys.up){
      // thrust in facing direction
      const ax = Math.cos(ship.angle) * SHIP_THRUST * dt * cheatOptions.speedMultiplier;
      const ay = Math.sin(ship.angle) * SHIP_THRUST * dt * cheatOptions.speedMultiplier;
      ship.vx += ax;
      ship.vy += ay;
    }
    // apply velocity and damping
    ship.x += ship.vx * dt * cheatOptions.speedMultiplier;
    ship.y += ship.vy * dt * cheatOptions.speedMultiplier;
    ship.vx *= Math.pow(SHIP_DAMPING, dt*60);
    ship.vy *= Math.pow(SHIP_DAMPING, dt*60);
    // keep ship inside bounds
    ship.x = Math.max(ship.w/2, Math.min(WIDTH - ship.w/2, ship.x));
    ship.y = Math.max(ship.h/2, Math.min(HEIGHT - ship.h/2, ship.y));

    // Meteors movement
    for(const m of meteors){
      m.x += m.vx * dt * cheatOptions.speedMultiplier;
      m.y += m.vy * dt * cheatOptions.speedMultiplier;
      m.angle += m.angular * dt * cheatOptions.speedMultiplier;
      if(m.y - m.r > HEIGHT || m.x + m.r < 0 || m.x - m.r > WIDTH){
        const nm = makeMeteor();
        // respawn above screen
        nm.y = rand(-120, -10);
        nm.x = rand(0, WIDTH);
        meteors.splice(meteors.indexOf(m), 1, nm);
      }
    }

    // Collision
    if(!cheatOptions.noclip){
      for(const m of meteors){
        const dx = m.x - ship.x;
        const dy = m.y - ship.y;
        const dist = Math.hypot(dx, dy);
        const shipRadius = Math.max(ship.w, ship.h) * 0.5;
        if(dist < m.r + shipRadius * 0.6){
          state = 'gameover';
          break;
        }
      }
    }

    // Per-minute acceleration and red tint increase
    minuteElapsed += dt;
    if(minuteElapsed >= 60){
      const minutes = Math.floor(minuteElapsed / 60);
      const factor = Math.pow(1.1, minutes); // 10% per minute
      for(const m of meteors){ m.vx *= factor; m.vy *= factor; }
      redLevel = Math.min(255, redLevel + RED_INCREASE_PER_MIN * minutes);
      minuteElapsed -= minutes * 60;
    }
    // Boss update: bullets and timer
    if(bossActive && boss){
      bossTimer += dt;
      // spawn bullets in waves
      if(bossTimer >= 0.4){
        bossTimer = 0;
        spawnBossBullets(boss);
      }
      // update bullets
      for(let i = bossBullets.length-1; i>=0; i--){
        const b = bossBullets[i];
        b.x += b.vx * dt;
        b.y += b.vy * dt;
        // remove off-screen
        if(b.x < -20 || b.x > WIDTH+20 || b.y < -20 || b.y > HEIGHT+20){ bossBullets.splice(i,1); continue; }
        // collision with ship
        if(!cheatOptions.noclip){
          const dx = b.x - ship.x, dy = b.y - ship.y;
          if(Math.hypot(dx,dy) < (b.r + Math.max(ship.w,ship.h)*0.25)){
            state = 'gameover';
            bossActive = false;
            break;
          }
        }
      }
    }
  }
}

function drawSplash(){
  ctx.clearRect(0,0,WIDTH,HEIGHT);
  ctx.fillStyle = '#000';
  ctx.fillRect(0,0,WIDTH,HEIGHT);
  // Title
  ctx.fillStyle = '#fff';
  ctx.textAlign = 'center';
  ctx.font = '28px Arial';
  ctx.fillText('VItjusha Games studio', WIDTH/2, HEIGHT/2 - 12);
  ctx.font = '14px Arial';
  const remain = Math.max(0, Math.ceil(SPLASH_SECONDS - splashTimer));
  ctx.fillStyle = 'rgba(255,255,255,0.9)';
  ctx.fillText('Starting in ' + remain + ' s', WIDTH/2, HEIGHT/2 + 18);
}

function drawGame(){
  // Background (rainbow cheat option)
  if(cheatOptions.rainbow){
    const t = performance.now() * 0.0001;
    const h = Math.floor((t*360) % 360);
    ctx.fillStyle = `hsl(${h} 70% 10%)`;
    ctx.fillRect(0,0,WIDTH,HEIGHT);
    // soft radial highlight
    const g = ctx.createRadialGradient(WIDTH/2, HEIGHT/2, 10, WIDTH/2, HEIGHT/2, Math.max(WIDTH, HEIGHT));
    g.addColorStop(0, `hsla(${(h+40)%360} 80% 50% / 0.06)`);
    g.addColorStop(1, `hsla(${(h+180)%360} 60% 20% / 0.02)`);
    ctx.fillStyle = g;
    ctx.fillRect(0,0,WIDTH,HEIGHT);
  } else {
    ctx.fillStyle = '#000';
    ctx.fillRect(0,0,WIDTH,HEIGHT);
  }

  // Meteors
  for(const m of meteors){
    ctx.save();
    ctx.translate(m.x, m.y);
    ctx.rotate(m.angle);
    // meteor body
    ctx.fillStyle = '#8a8a8a';
    ctx.beginPath();
    const pts = m.points;
    for(let i=0;i<pts.length;i++){
      const p = pts[i];
      if(i===0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y);
    }
    ctx.closePath();
    ctx.fill();
    // shadow
    ctx.fillStyle = 'rgba(0,0,0,0.15)';
    ctx.beginPath();
    for(let i=0;i<pts.length;i++){
      const p = pts[i];
      if(i===0) ctx.moveTo(p.x*0.88+6, p.y*0.88+6); else ctx.lineTo(p.x*0.88+6, p.y*0.88+6);
    }
    ctx.closePath(); ctx.fill();

    // hitbox
    if(cheatOptions.showHitboxes){
      ctx.strokeStyle = 'rgba(255,0,0,0.9)';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.arc(0, 0, m.r, 0, Math.PI*2);
      ctx.stroke();
    }

    ctx.restore();
  }

  // Ship (rotating with thrust flame)
  ctx.save();
  ctx.translate(ship.x, ship.y);
  ctx.rotate(ship.angle + Math.PI/2);
  // body
  ctx.fillStyle = '#4ec0ff';
  ctx.beginPath();
  ctx.moveTo(0, -ship.h/2);
  ctx.lineTo(-ship.w/2, ship.h/2);
  ctx.lineTo(ship.w/2, ship.h/2);
  ctx.closePath();
  ctx.fill();
  // thrust flame
  if(keys.up){
    const flameLen = 18 + Math.random()*6;
    ctx.fillStyle = 'orange';
    ctx.beginPath();
    ctx.moveTo(0, ship.h/2 + 2);
    ctx.lineTo(-6, ship.h/2 + flameLen);
    ctx.lineTo(6, ship.h/2 + flameLen);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();

  // Red overlay depending on redLevel
  if(redLevel > 0){
    ctx.fillStyle = `rgba(${redLevel},0,0,${OVERLAY_ALPHA})`;
    ctx.fillRect(0,0,WIDTH,HEIGHT);
  }

  // ship hitbox
  if(cheatOptions.showHitboxes){
    ctx.strokeStyle = 'rgba(0,255,0,0.9)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.arc(ship.x, ship.y, Math.max(ship.w, ship.h)*0.5*0.6, 0, Math.PI*2);
    ctx.stroke();
  }

  // HUD: score and best
  ctx.fillStyle = '#fff';
  ctx.font = '14px Arial';
  ctx.textAlign = 'left';
  ctx.fillText('Score: ' + score, 8, 18);
  ctx.textAlign = 'right';
  ctx.fillText('Best: ' + bestScore, WIDTH-8, 18);

  // Badges
  let bx = 8, by = 32;
  for(const b of BADGES){
    ctx.fillStyle = b.unlocked ? b.color : 'rgba(255,255,255,0.12)';
    ctx.beginPath();
    ctx.arc(bx+10, by+10, 10, 0, Math.PI*2);
    ctx.fill();
    ctx.fillStyle = '#000';
    ctx.font = '10px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(b.label, bx+10, by+13);
    bx += 26;
  }

  // draw boss if active
  if(bossActive && boss){
    // boss body
    ctx.save();
    ctx.translate(boss.x, boss.y);
    ctx.fillStyle = '#6633aa';
    ctx.beginPath(); ctx.arc(0,0,boss.r,0,Math.PI*2); ctx.fill();
    // eyes
    ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(-boss.r*0.25,-boss.r*0.15, boss.r*0.18,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(boss.r*0.25,-boss.r*0.15, boss.r*0.18,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#000'; ctx.beginPath(); ctx.arc(-boss.r*0.25,-boss.r*0.15,boss.r*0.07,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(boss.r*0.25,-boss.r*0.15,boss.r*0.07,0,Math.PI*2); ctx.fill();
    ctx.restore();

    // draw boss bullets
    for(const b of bossBullets){
      ctx.fillStyle = 'red';
      ctx.beginPath(); ctx.arc(b.x,b.y,b.r,0,Math.PI*2); ctx.fill();
    }
    // boss label
    ctx.fillStyle='rgba(255,80,80,0.95)'; ctx.font='16px Arial'; ctx.textAlign='center';
    ctx.fillText('BOSS', WIDTH/2, 26);
  }
}

function drawGameOver(){
  drawGame();
  ctx.fillStyle = 'rgba(0,0,0,0.5)';
  ctx.fillRect(0,0,WIDTH,HEIGHT);
  ctx.fillStyle = 'red';
  ctx.font = '48px Arial';
  ctx.textAlign = 'center';
  ctx.fillText('GAME OVER', WIDTH/2, HEIGHT/2);
  ctx.font = '16px Arial';
  ctx.fillStyle = '#fff';
  ctx.fillText('Tap to restart', WIDTH/2, HEIGHT/2 + 36);

  // update best score (do NOT auto-save; user must press Save)
  if(score > bestScore){
    bestScore = score;
  }
}

function draw(){
  // clear
  ctx.clearRect(0,0,WIDTH,HEIGHT);
  if(state === 'splash') drawSplash();
  else if(state === 'game') drawGame();
  else if(state === 'gameover') drawGameOver();
}

// --- Save / Load UI handlers (download and file load)
const btnSave = document.getElementById('btnSave');
const btnLoad = document.getElementById('btnLoad');
const fileInput = document.getElementById('fileInput');
const btnTestAudio = document.getElementById('btnTestAudio');
const btnOpenCheat = document.getElementById('btnOpenCheat');
const debugDiv = document.getElementById('debug');
const btnPlayPCK = document.getElementById('btnPlayPCK');
const btnPlayBoss = document.getElementById('btnPlayBoss');
const btnSpawnBoss = document.getElementById('btnSpawnBoss');

if(btnSave){
  btnSave.addEventListener('click', ()=>{
    // ensure latest save state
    saveNow();
    const data = localStorage.getItem(SAVE_KEY) || JSON.stringify({bestScore:bestScore,badges:{}});
    const blob = new Blob([data], {type: 'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'save.hasave';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  });
}

if(btnLoad && fileInput){
  btnLoad.addEventListener('click', ()=> fileInput.click());
  fileInput.addEventListener('change', async (e)=>{
    const f = e.target.files && e.target.files[0];
    if(!f) return;
    try{
      const text = await f.text();
      // basic validation
      JSON.parse(text);
      localStorage.setItem(SAVE_KEY, text);
      loadSave();
      alert('Save loaded.');
    }catch(err){
      alert('Failed to load save: ' + err.message);
    } finally {
      fileInput.value = '';
    }
  });
}

// Expose save/load to console if needed
window.saveNow = saveNow;
window.loadSave = loadSave;

// Debug helpers: show messages in debug panel so user doesn't need DevTools
function debugLog(msg, level='info'){
  try{
    if(!debugDiv) return;
    const line = document.createElement('div');
    line.className = 'line';
    const time = new Date().toLocaleTimeString();
    line.textContent = `[${time}] ${msg}`;
    if(level === 'error') line.style.color = '#f66';
    debugDiv.appendChild(line);
    // keep last 8 lines
    while(debugDiv.children.length > 8) debugDiv.removeChild(debugDiv.firstChild);
  }catch(e){}
}

window.addEventListener('error', (ev)=>{
  debugLog('Error: ' + (ev.message || ev.toString()), 'error');
});
window.addEventListener('unhandledrejection', (ev)=>{
  debugLog('Promise rejected: ' + (ev.reason && ev.reason.message ? ev.reason.message : ev.reason), 'error');
});

// Wire the secret-code input field (if present) so user can type code and press Enter
window.addEventListener('DOMContentLoaded', ()=>{
  const codeInput = document.getElementById('devCodeInput');
  const btnCode = document.getElementById('btnCodeEnter');
  function submitCode(val){
    if(!val) return;
    const vRaw = String(val);
    const v = vRaw.trim().toLowerCase();
    // normalize: remove non-alphanumeric characters to avoid accidental spacing/unicode issues
    const vNorm = v.replace(/[^a-z0-9]/g,'');
    const secretNorm = SECRET_CODE.replace(/[^a-z0-9]/g,'').toLowerCase();
    // accept either the original secret or the special phrase 'subtodevvitjusha'
    const alt = 'subtodevvitjusha';
    const codeOhWow = 'ohwow';
    const codeRainbow = 'rainbowship';
    if(vNorm === secretNorm || vNorm === alt){
      cheatUnlocked = true;
      try{ localStorage.setItem('subToDevVitjusha','1'); }catch(e){}
      window.SubToDevVitjusha = true;
      // reveal hidden dev buttons
      try{
        ['btnTestAudio','btnPlayPCK','btnPlayBoss','btnSpawnBoss'].forEach(id=>{ const el=document.getElementById(id); if(el) el.style.display=''; });
      }catch(e){}
      try{ showCheatPanel(); }catch(e){}
      debugLog('Secret code accepted — Dev Console enabled and buttons revealed');
      if(codeInput) codeInput.value = '';
    } else if(vNorm === codeOhWow){
      // Grant 150 banked points once. Use the shop save key used by shop.js
      try{
        const key = 'vitjusha_game_shop_v1';
        const raw = localStorage.getItem(key) || '{}';
        const saved = JSON.parse(raw || '{}');
        saved.banked = saved.banked || 0;
        saved.codes = saved.codes || {};
        if(saved.codes.ohwow){
          debugLog('OhWoW code already used','error');
        } else {
          saved.banked += 150;
          saved.codes.ohwow = true;
          localStorage.setItem(key, JSON.stringify(saved));
          debugLog('OhWoW accepted — +150 points added to your bank (one-time)', 'info');
        }
        if(codeInput) codeInput.value = '';
      }catch(e){ debugLog('OhWoW processing error: '+e.message,'error'); }
    } else if(vNorm === codeRainbow){
      try{
        window.rainbowShipUnlocked = true;
        localStorage.setItem('rainbowShipUnlocked','1');
        debugLog('RainbowShip accepted — your ship will now be rainbow!', 'info');
        if(codeInput) codeInput.value = '';
      }catch(e){ debugLog('RainbowShip processing error: '+e.message,'error'); }
    } else {
      debugLog('Secret code incorrect (normalized input: ' + vNorm + ')','error');
      if(codeInput){ codeInput.style.transition='background 0.18s'; codeInput.style.background = '#f66'; setTimeout(()=>{ codeInput.style.background = ''; }, 300); }
    }
  }
  if(codeInput){
    codeInput.addEventListener('keydown', (e)=>{ if(e.key === 'Enter') submitCode(codeInput.value); });
  }
  if(btnCode){ btnCode.addEventListener('click', ()=> submitCode(codeInput && codeInput.value)); }
});

// Wire Test Audio and Open Cheat buttons so user can trigger without DevTools
if(btnTestAudio){
  // hide by default per user's request
  btnTestAudio.style.display = 'none';
  btnTestAudio.addEventListener('click', ()=>{
    debugLog('Attempting to start audio...');
    try{ startMusic(); debugLog('startMusic called'); }catch(e){ debugLog('startMusic error: ' + e.message, 'error'); }
  });
}

if(btnPlayPCK){ btnPlayPCK.style.display = 'none'; btnPlayPCK.addEventListener('click', ()=>{ debugLog('Play PCK now'); try{ stopFileMusic(); musicAudio = new Audio('PCK.mp3'); musicAudio.play().then(()=>debugLog('PCK playing')).catch(e=>debugLog('PCK play failed: '+e.message,'error')); }catch(e){ debugLog('playPCK error: '+e.message,'error') } }); }

if(btnPlayBoss){ btnPlayBoss.style.display = 'none'; btnPlayBoss.addEventListener('click', ()=>{ debugLog('Play Boss now'); try{ stopFileMusic(); bossAudio = new Audio('boss.mp3'); bossAudio.loop = true; bossAudio.play().then(()=>{ debugLog('boss playing'); spawnBoss(); }).catch(e=>debugLog('boss play failed: '+e.message,'error')); }catch(e){ debugLog('playBoss error: '+e.message,'error') } }); }

if(btnSpawnBoss){ btnSpawnBoss.style.display = 'none'; btnSpawnBoss.addEventListener('click', ()=>{ debugLog('Manual spawn boss requested'); try{ spawnBoss(); debugLog('Boss spawned'); }catch(e){ debugLog('spawn error: '+e.message,'error'); } }); }

// Set persistent Dev Console flag from previous session (no button present)
try{ window.SubToDevVitjusha = !!localStorage.getItem('subToDevVitjusha'); }catch(e){ window.SubToDevVitjusha = false; }
// User-requested: enable subscription flag now
try{ localStorage.setItem('subToDevVitjusha','1'); window.SubToDevVitjusha = true; debugLog('SubToDevVitjusha enabled by user','info'); }catch(e){}

// MOBILE: Menu panel toggle
window.addEventListener('DOMContentLoaded', () => {
  const btnMenu = document.getElementById('btnMenu');
  const menuPanel = document.getElementById('menuPanel');
  const btnCloseMenu = document.getElementById('btnCloseMenu');
  
  if (btnMenu && menuPanel) {
    btnMenu.addEventListener('click', () => {
      menuPanel.style.display = menuPanel.style.display === 'none' ? '' : 'none';
    });
  }
  
  if (btnCloseMenu && menuPanel) {
    btnCloseMenu.addEventListener('click', () => {
      menuPanel.style.display = 'none';
    });
  }
  
  // Make sure buttons are visible in menu (they were hidden in original)
  const menuButtons = [btnTestAudio, btnPlayPCK, btnPlayBoss, btnSpawnBoss];
  menuButtons.forEach(btn => {
    if (btn) btn.style.display = '';
  });
});

// MOBILE: Performance optimizations
// Reduce meteor count on lower-end devices
if (navigator.hardwareConcurrency && navigator.hardwareConcurrency < 4) {
  // Reduce complexity on weaker devices
  const METEOR_COUNT_MOBILE = 4;
  while (meteors.length > METEOR_COUNT_MOBILE) {
    meteors.pop();
  }
}

// Prevent double-tap zoom
document.addEventListener('touchstart', (e) => {
  if (e.touches.length > 1) {
    e.preventDefault();
  }
}, { passive: false });

let lastTouchEnd = 0;
document.addEventListener('touchend', (e) => {
  const now = Date.now();
  if (now - lastTouchEnd <= 300) {
    e.preventDefault();
  }
  lastTouchEnd = now;
}, { passive: false });


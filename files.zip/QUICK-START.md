# 🚀 QUICK START GUIDE

## Test Right Now (On Your Computer)

1. **Download all the files**
2. **Open `index-mobile.html`** in Chrome
3. **Press F12** (open DevTools)
4. **Click the phone icon** (top-left corner of DevTools)
5. **Select "iPhone 12 Pro"** or any phone
6. **Reload the page**
7. **Click the touch buttons** with your mouse!

That's it! You're playing the mobile version!

---

## Put It On Your Phone (Easy Way)

### Method 1: Use Your Computer as Server

1. **Put all files in one folder**
2. **Open terminal/command prompt** in that folder
3. **Run:** `python -m http.server 8000`
   - (Or use any local server)
4. **Find your computer's IP address**
   - Windows: `ipconfig` 
   - Mac/Linux: `ifconfig`
5. **On your phone browser:** Go to `http://YOUR-IP:8000`
6. **Tap "Add to Home Screen"**

### Method 2: GitHub Pages (Free Hosting)

1. **Create GitHub account** (free)
2. **Create new repository** called "space-game"
3. **Upload all files**
4. **Go to Settings → Pages**
5. **Enable Pages** from main branch
6. **Visit the URL** they give you
7. **On phone: Add to home screen!**

---

## Convert to Real Android App

### Easiest: AppsGeyser (No Coding)

1. Go to **appsgeyser.com**
2. Click **"Create App"**
3. Select **"Website"**
4. Enter your game URL (from GitHub Pages)
5. Customize app name & icon
6. Download APK
7. Install on Android phone!

### Pro Way: Cordova (Takes 30 min)

```bash
# Install Node.js first from nodejs.org
# Then in terminal:

npm install -g cordova
cordova create MyGame
cd MyGame

# Copy your game files to www/ folder
# Then:

cordova platform add android
cordova build android
```

APK will be in: `platforms/android/app/build/outputs/apk/debug/`

---

## File Checklist ✅

Make sure you have all these:

- [ ] index-mobile.html
- [ ] styles-mobile.css
- [ ] main-mobile.js
- [ ] data/P-1/shop.js
- [ ] data/P-2/mechanics.js
- [ ] data/P-3/misc.js
- [ ] PCK.mp3
- [ ] boss.mp3

---

## Troubleshooting

**"Touch buttons don't work"**
→ Make sure JavaScript is enabled, refresh page

**"No sound"**
→ Tap the ☰ menu button, then "Test Audio"

**"Game is too small/big"**
→ Rotate your device, it auto-adjusts

**"Can't find files"**
→ Make sure folder structure matches checklist above

---

**Need more help?** Check README.md for detailed instructions!
